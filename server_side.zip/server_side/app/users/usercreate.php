<?php

include "db.php";
include "function.php";

$jsonArray = array();
$jsonArray["hata"] = FALSE;
$_code = 200;

$_method = $_SERVER["REQUEST_METHOD"];

if($_method  == "POST") {

	$gelen_veri = json_decode(file_get_contents("php://input"));

	if(	isset($gelen_veri->userName) && 
        isset($gelen_veri->userPassword) ){

		$userName = $gelen_veri->userName;
        $userPassword = $gelen_veri->userPassword;


        // ADD DATA IN DATABASE:

        $ex = $db->prepare("INSERT INTO users set
 				userName= :uname,
 				userPassword= :upass");
            $ekle = $ex->execute(array(
                "uname" => $userName,
                "upass" => $userPassword
                
            ));
            if($ekle) {
                $_code = 201;
                $jsonArray["mesaj"] = "Kayıt gerçekleşti";
            }else {
                $_code = 400;
                $jsonArray["hata"] = TRUE; // bir hata olduğu bildirilsin.
                $jsonArray["mesaj"] = "Sistem Hatası.";
            }
	}

SetHeader($_code);
$jsonArray["code"] = $_code;
echo json_encode($jsonArray);
}
?>