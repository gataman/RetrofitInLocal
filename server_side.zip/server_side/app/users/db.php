<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "retrofit";

try {

	$db = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
			$db -> query("SET CHARACTER SET utf8");
	
} catch (PDOExcetion $e) {
	die($e -> getMessage());
	
}

?>